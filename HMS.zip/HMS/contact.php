 <!DOCTYPE html>
<html>
<title>Contact Details</title>

<style>
       
         body{
             background: skyblue;
             }     
          
     </style>
 

<body>
 <div style="background-color:MediumSeaGreen;" > 
<img src="iiitm-logo.png" style="float:left;width="115px" height="90px">
 <img src="hindi.png">           
 <h2><a href="#">Indian Institute of Information Technology Senapati, Manipur</a></h2>

             
 <p> Postal address:<br>

    Indian Institute of Information Technology Senapati, Manipur
    Mantripukhri, Imphal, India - 795002
    Contact No. - +91 385-242-1017 / 2920 <br>

    E-mails:<br>
 
    Director	                      director@iiitmanipur.ac.in,	
    Registrar	                      registrar@iiitmanipur.ac.in,	
    Academic section	              academic@iiitmanipur.ac.in,
    Training and placement cell	      training@iiitmanipur.ac.in,	
    R&D cell	                      rnd@iiitmanipur.ac.in,	
    Teqip Phase III cell	      teqip@iiitmanipur.ac.in,	 
        
  
</p>






</body>
</html> 
