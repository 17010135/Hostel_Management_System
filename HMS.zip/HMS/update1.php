<!DOCTYPE html>
<html>
<head> 
<title></title>
      <style>
       
         body{
             background: skyblue;
             }     
          
     </style>
 
</head>
<body>
<h2>Enter the Roll Number</h2>

<form name="display" action="update.php" method="POST" >
<input type="text" name="roll" />
<input type="submit" value=" submit" name="" /></br></br>
</form>
</body>
</html>

